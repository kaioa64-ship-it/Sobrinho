import React from 'react';
import { LogoHorizontalBranca } from '../assets/coagroLogos';
import { Code2 } from 'lucide-react';

interface HeaderProps {
  onOpenJsonModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenJsonModal }) => {
  return (
    <header className="bg-[#004d40] text-white shadow-md border-b-4 border-[#ffab00] py-3.5 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="w-10 sm:w-24" /> {/* Spacer to balance layout */}

        {/* Official Coagro Logo alone */}
        <div className="w-44 sm:w-56 py-0.5 flex justify-center">
          <LogoHorizontalBranca className="h-9 sm:h-11 w-auto" />
        </div>

        {/* Subtle JSON button */}
        <div className="w-10 sm:w-24 flex justify-end">
          {onOpenJsonModal && (
            <button
              onClick={onOpenJsonModal}
              title="Visualizar JSON técnico estruturado"
              className="px-2.5 py-1.5 rounded-lg bg-black/20 hover:bg-black/30 text-white/90 hover:text-white text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition"
            >
              <Code2 className="w-3.5 h-3.5 text-[#ffab00]" />
              <span className="hidden sm:inline">JSON</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

