import React from 'react';

interface ArtCtaProps {
  ctaText: string;
  fullWidth?: boolean;
}

export const ArtCta: React.FC<ArtCtaProps> = ({ ctaText, fullWidth = true }) => {
  if (!ctaText || !ctaText.trim()) return null;

  return (
    <div className={`${fullWidth ? 'w-full' : 'w-full max-w-sm'} min-h-11 px-4 rounded-2xl bg-[#001C71] text-white flex items-center justify-center gap-2 shadow-xl border border-white/20 select-none`}>
      <span className="text-[#ffab00] font-black text-xs shrink-0">▶</span>
      <span className="font-['Exo_2'] font-black uppercase tracking-wider text-sm text-center">
        {ctaText}
      </span>
    </div>
  );
};
