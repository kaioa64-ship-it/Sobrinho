import React from 'react';
import { CheckCircle } from 'lucide-react';

interface BenefitsListProps {
  benefits: string[];
  variant: 'badges-horizontal' | 'list-vertical';
  textColor?: string;
}

export const BenefitsList: React.FC<BenefitsListProps> = ({
  benefits,
  variant,
  textColor = 'text-white',
}) => {
  if (benefits.length === 0) return null;

  if (variant === 'list-vertical') {
    return (
      <div className="space-y-2 text-left">
        {benefits.map((benefit, index) => (
          <div key={`${index}-${benefit}`} className="flex items-start gap-2">
            <CheckCircle className="w-4 h-4 text-[#ffab00] shrink-0 mt-0.5" />
            <span className={`text-[11px] font-semibold leading-tight ${textColor}`}>
              {benefit}
            </span>
          </div>
        ))}
      </div>
    );
  }

  // Variant: badges-horizontal (Hero Central)
  const isLightText = textColor.includes('#001C71') || textColor.includes('gray');

  return (
    <div className="flex flex-col items-center justify-center gap-1.5 min-h-0 w-full">
      {benefits.map((benefit, index) => (
        <div
          key={`${index}-${benefit}`}
          className={`max-w-[94%] min-h-8 px-3 py-1.5 rounded-full flex items-center justify-center gap-2 text-[11px] font-semibold ${
            isLightText
              ? 'bg-white/90 border border-gray-200 text-[#001C71] shadow-2xs'
              : 'bg-black/40 border border-white/20 text-white shadow-2xs'
          }`}
        >
          <CheckCircle className="w-3.5 h-3.5 text-[#ffab00] shrink-0" />
          <span className="leading-tight text-center">{benefit}</span>
        </div>
      ))}
    </div>
  );
};
