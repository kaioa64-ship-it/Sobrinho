import React from 'react';
import { CommunicationMode } from '../../lib/communicationMode';

interface PriceCardProps {
  mode: CommunicationMode;
  oldPrice?: string;
  currentPrice: string;
  condition?: string;
}

export const PriceCard: React.FC<PriceCardProps> = ({
  mode,
  oldPrice,
  currentPrice,
  condition,
}) => {
  const isPromotion = mode === 'PROMOTION';

  return (
    <div className="min-w-[150px] bg-[#ffab00] text-[#001C71] px-4 py-3 rounded-2xl shadow-2xl border-2 border-white/80 flex flex-col items-center">
      {isPromotion && oldPrice && (
        <div className="text-[10px] font-bold opacity-75 line-through whitespace-nowrap">
          DE: {oldPrice}
        </div>
      )}

      <div className="flex items-baseline justify-center flex-nowrap whitespace-nowrap gap-1">
        {isPromotion && (
          <span className="text-[10px] font-black uppercase font-['Exo_2']">
            POR:
          </span>
        )}
        <span className="text-[11px] font-black font-['Exo_2']">R$</span>
        <span className="text-[25px] font-black font-['Exo_2'] tracking-tight">
          {currentPrice}
        </span>
      </div>

      {condition && (
        <span className="mt-0.5 text-[9px] font-extrabold uppercase tracking-wider whitespace-nowrap">
          {condition}
        </span>
      )}
    </div>
  );
};
