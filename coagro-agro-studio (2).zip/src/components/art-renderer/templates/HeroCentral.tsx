import React from 'react';
import { LogoVariant } from '../../../assets/coagroLogos';
import { CommunicationMode } from '../../../lib/communicationMode';
import { ProductOrientation } from '../../../lib/alphaBounds';
import { renderTitleWithHighlight } from '../../../lib/renderHelper';
import { ArtHeader } from '../ArtHeader';
import { BenefitsList } from '../BenefitsList';
import { PriceCard } from '../PriceCard';
import { ArtCta } from '../ArtCta';

export interface HeroCentralTemplateProps {
  title: string;
  highlight: string;
  titleColor?: string;
  subtitle?: string;
  subtitleColor?: string;
  processedProduct: string;
  isStory: boolean;
  logoVariant?: LogoVariant;
  mode: CommunicationMode;
  hasPrice: boolean;
  currentPrice: string;
  oldPrice?: string;
  condition?: string;
  benefits: string[];
  cta: string;
  orientation?: ProductOrientation;
  isWide?: boolean;
  isSmall?: boolean;
  imageBoxFormat?: 'rectangular' | 'square';
}

/**
 * Layout HeroCentral - Estrutura de Bounding Box Dedicada e Fluxo Flexbox Vertical
 *
 * Princípios de Design & Temas:
 * 1. Fundo transparente: herda integralmente o tema e o background layer do canvas (campo, verde, azul, clean-branco).
 * 2. Localização dos itens inquebrável (flexbox vertical):
 *    - Topo: Header (Logo Coagro + Título de Impacto + Subtítulo do Produto)
 *    - Centro: Bounding Box exclusivo para o produto com ancoragem object-bottom (Retangular 900x630 ou Quadrado 630x630)
 *    - Módulo de Preço: flutuando sobre o canto inferior da imagem (position absolute fora do fluxo DOM)
 *    - Inferior: 3 diferenciais técnicos (BenefitsList adaptativo)
 *    - Rodapé: Botão CTA (ArtCta)
 * 3. Cores dinâmicas: respeitam titleColor e subtitleColor do tema ativo.
 */
export const HeroCentral: React.FC<HeroCentralTemplateProps> = ({
  title,
  highlight,
  titleColor = 'text-white',
  subtitle,
  subtitleColor = 'text-[#E5E7EB]',
  processedProduct,
  isStory,
  logoVariant = 'h-branca',
  mode,
  hasPrice,
  currentPrice,
  oldPrice,
  condition,
  benefits = [],
  cta,
  orientation,
  isSmall,
  imageBoxFormat,
}) => {
  // Dimensões dinâmicas suportadas para a Zona de Segurança da Imagem (Bounding Box)
  // Retangular (proporção 900x630 = ~1.428) OU Quadrado (proporção 630x630 = 1:1)
  const isSquareBox =
    imageBoxFormat === 'square' ||
    (!imageBoxFormat && (orientation === 'compact' || orientation === 'small' || isSmall));

  // Normalização dos 3 diferenciais técnicos
  const displayBenefits =
    benefits && benefits.length > 0
      ? benefits.slice(0, 3)
      : [
          'Qualidade e Procedência Garantida',
          'Assistência Técnica Especializada',
          'Pronta Entrega no Campo',
        ];

  return (
    <div className="relative z-10 w-full h-full flex flex-col justify-between items-center px-4 py-4 sm:px-6 sm:py-5 select-none font-['Inter']">
      {/* 1. Bloco Superior (Header & Títulos) */}
      {/* Ocupa apenas o topo e empurra a imagem para baixo sem sobreposição */}
      <header className="w-full flex flex-col items-center shrink-0">
        <ArtHeader logoVariant={logoVariant} isStory={isStory} align="center" />

        {title ? (
          <h1
            className={`font-['Exo_2'] font-black uppercase text-center mt-2 leading-[1.08] tracking-tight drop-shadow-md max-w-[94%] ${titleColor} ${
              isStory ? 'text-xl sm:text-2xl' : 'text-lg sm:text-xl'
            }`}
          >
            {renderTitleWithHighlight(title, highlight, 'text-[#ffab00]')}
          </h1>
        ) : null}

        {subtitle ? (
          <p
            className={`mt-1 font-semibold uppercase text-center leading-snug drop-shadow-sm max-w-[94%] ${subtitleColor} ${
              isStory ? 'text-xs sm:text-sm' : 'text-[11px] sm:text-xs'
            }`}
          >
            {subtitle}
          </p>
        ) : null}
      </header>

      {/* 2. Zona de Segurança da Imagem (O Bounding Box) */}
      {/* Dimensões dinâmicas suportadas: Retangular (900x630) OU Quadrado (630x630) */}
      {/* relative para ancoragem segura do cartão de preço flutuante */}
      <div
        className={`relative flex items-center justify-center mx-auto my-auto shrink-0 ${
          isSquareBox
            ? isStory
              ? 'w-[72%] aspect-square max-h-[38%]'
              : 'w-[68%] aspect-square max-h-[44%]'
            : isStory
            ? 'w-[94%] aspect-[900/630] max-h-[40%]'
            : 'w-[90%] aspect-[900/630] max-h-[46%]'
        }`}
      >
        {/* Container interno de contenção estrita da imagem (nunca vaza do contêiner) */}
        <div className="w-full h-full flex items-center justify-center overflow-hidden">
          {processedProduct ? (
            <img
              src={processedProduct}
              alt={subtitle || 'Produto Coagro'}
              referrerPolicy="no-referrer"
              className="max-w-full max-h-full object-contain object-bottom pointer-events-none select-none filter drop-shadow-[0_15px_25px_rgba(0,0,0,0.65)]"
            />
          ) : null}
        </div>

        {/* 3. Módulo de Preço (Sobreposição Segura) */}
        {/* Flutua exclusivamente sobre o canto inferior da imagem, FORA do fluxo normal do DOM */}
        {/* Renderizado nos modos Promoção e Preço Único; oculto no modo Informativo */}
        {hasPrice && currentPrice && (
          <div className="absolute -bottom-3 -right-2 sm:-bottom-4 sm:-right-2 z-50 pointer-events-none select-none">
            <PriceCard
              mode={mode}
              oldPrice={oldPrice}
              currentPrice={currentPrice}
              condition={condition}
            />
          </div>
        )}
      </div>

      {/* 4. Bloco Inferior (Diferenciais Técnicos / Bullets) */}
      <section className="w-full max-w-[94%] shrink-0 my-1.5 sm:my-2">
        <BenefitsList
          benefits={displayBenefits}
          variant="badges-horizontal"
          textColor={titleColor}
        />
      </section>

      {/* 5. Rodapé (Call to Action) */}
      <footer className="w-full max-w-[94%] shrink-0 mt-auto pt-1 pb-1 flex justify-center">
        <ArtCta ctaText={cta} fullWidth />
      </footer>
    </div>
  );
};
