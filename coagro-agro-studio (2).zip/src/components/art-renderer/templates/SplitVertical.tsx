import React from 'react';
import { LogoVariant } from '../../../assets/coagroLogos';
import { CommunicationMode } from '../../../lib/communicationMode';
import { renderTitleWithHighlight } from '../../../lib/renderHelper';
import { PriceCard } from '../PriceCard';
import { ArtHeader } from '../ArtHeader';
import { BenefitsList } from '../BenefitsList';
import { ArtCta } from '../ArtCta';

interface SplitVerticalTemplateProps {
  title: string;
  highlight: string;
  titleColor: string;
  subtitle?: string;
  subtitleColor: string;
  processedProduct: string;
  isStory: boolean;
  logoVariant: LogoVariant;
  mode: CommunicationMode;
  hasPrice: boolean;
  currentPrice: string;
  oldPrice?: string;
  condition?: string;
  benefits: string[];
  cta: string;
  isWide?: boolean;
}

export const SplitVertical: React.FC<SplitVerticalTemplateProps> = ({
  title,
  highlight,
  titleColor,
  subtitle,
  subtitleColor,
  processedProduct,
  isStory,
  logoVariant,
  mode,
  hasPrice,
  currentPrice,
  oldPrice,
  condition,
  benefits,
  cta,
  isWide,
}) => {
  // Ajuste de largura da imagem para equipamentos horizontais/largos no Split (Fase 4)
  const productWidth = isStory ? (isWide ? '106%' : '118%') : '135%';
  const productMarginLeft = isStory ? '0%' : '-12%';

  return (
    <div className="relative z-10 h-full flex flex-col w-full select-none">
      {/* Corpo Dividido em Duas Colunas */}
      <div className="flex-1 min-h-0 grid grid-cols-[48%_52%]">
        {/* Coluna Esquerda: Produto com escala adaptativa e ancoragem (Hierarquia visual atrás: z-10) */}
        <div className="relative z-10 flex items-center justify-center overflow-visible px-1">
          {processedProduct ? (
            <img
              src={processedProduct}
              alt="Produto Agro Coagro"
              referrerPolicy="no-referrer"
              style={{
                width: productWidth,
                maxWidth: 'none',
                marginLeft: productMarginLeft,
                filter: 'drop-shadow(0 15px 20px rgba(0,0,0,.65))',
              }}
              className="max-h-[90%] object-contain object-center pointer-events-none"
            />
          ) : null}
        </div>

        {/* Coluna Direita: Informações, Benefícios e Bloco de Preço (Hierarquia visual na frente: z-20) */}
        <div className="relative z-20 h-full flex flex-col justify-center gap-4 pt-7 pb-4 pr-5 pl-2 overflow-visible">
          {/* Logo Coagro Alinhado */}
          <ArtHeader logoVariant={logoVariant} isStory={isStory} align="left" />

          {/* Título de Impacto e Subtítulo (Sempre acima da imagem em z-30) */}
          {title ? (
            <div className="relative z-30">
              <h2 className="font-['Exo_2'] font-black uppercase text-2xl leading-[1.08] tracking-tight drop-shadow-md">
                {renderTitleWithHighlight(title, highlight, titleColor)}
              </h2>
              {subtitle && (
                <p className={`mt-1.5 text-xs font-bold tracking-wide uppercase leading-snug drop-shadow-sm ${subtitleColor}`}>
                  {subtitle}
                </p>
              )}
            </div>
          ) : null}

          {/* Diferenciais Técnicos Sem Truncamento */}
          <div className="relative z-30">
            <BenefitsList benefits={benefits} variant="list-vertical" />
          </div>

          {/* Módulo de Preço Adaptativo */}
          {hasPrice && currentPrice && (
            <div className="relative z-30">
              <PriceCard
                mode={mode}
                oldPrice={oldPrice}
                currentPrice={currentPrice}
                condition={condition}
              />
            </div>
          )}
        </div>
      </div>

      {/* Rodapé: Botão CTA em Largura Total (RF-04) */}
      <div className="shrink-0 px-5 pb-5">
        <ArtCta ctaText={cta} fullWidth />
      </div>
    </div>
  );
};
