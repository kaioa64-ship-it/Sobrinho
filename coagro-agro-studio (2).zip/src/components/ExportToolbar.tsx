import React, { useState } from 'react';
import { CanvasFormat, CanvasTheme, AgroContent, TemplateLayout } from '../types/agro';
import { LogoVariant } from '../assets/coagroLogos';
import { toPng } from 'html-to-image';
import { uploadToGoogleDrive } from '../lib/googleDrive';
import { getAccessToken, googleSignIn } from '../lib/firebase';
import { formatCleanRenderJson } from './JsonViewerModal';
import {
  Download,
  HardDrive,
  Copy,
  Check,
  Palette,
  Layout,
  FileCode,
  ExternalLink,
  RefreshCw,
  Columns2,
  Maximize2,
  Box,
} from 'lucide-react';

interface ExportToolbarProps {
  content: AgroContent;
  format: CanvasFormat;
  onSetFormat: (format: CanvasFormat) => void;
  theme: CanvasTheme;
  onSetTheme: (theme: CanvasTheme) => void;
  templateLayout?: TemplateLayout;
  onSetTemplateLayout?: (template: TemplateLayout) => void;
  imageBoxFormat?: 'rectangular' | 'square';
  onSetImageBoxFormat?: (fmt: 'rectangular' | 'square') => void;
  logoVariant: LogoVariant;
  onSetLogoVariant: (variant: LogoVariant) => void;
  user?: any;
  onPromptLogin?: () => void;
  targetElementId?: string;
}

export const ExportToolbar: React.FC<ExportToolbarProps> = ({
  content,
  format,
  onSetFormat,
  theme,
  onSetTheme,
  templateLayout = 'split-vertical',
  onSetTemplateLayout,
  imageBoxFormat = 'rectangular',
  onSetImageBoxFormat,
  logoVariant,
  onSetLogoVariant,
  targetElementId = 'agro-single-art-canvas',
}) => {
  const [isExportingPng, setIsExportingPng] = useState(false);
  const [isSavingDrive, setIsSavingDrive] = useState(false);
  const [driveSavedLink, setDriveSavedLink] = useState<string | null>(null);
  const [copiedType, setCopiedType] = useState<'json' | 'caption' | null>(null);

  // Download high-resolution PNG
  const handleDownloadPng = async () => {
    try {
      setIsExportingPng(true);
      const element = document.getElementById(targetElementId);
      if (!element) {
        throw new Error('Elemento da arte não encontrado para renderização.');
      }

      const dataUrl = await toPng(element, {
        quality: 0.98,
        pixelRatio: 2.5,
      });

      const filename = `coagro-agro-${(content.formato || 'post').toLowerCase()}-${Date.now()}.png`;
      const link = document.createElement('a');
      link.download = filename;
      link.href = dataUrl;
      link.click();
    } catch (err: any) {
      console.error('Erro ao exportar PNG:', err);
      alert('Erro ao gerar imagem: ' + err.message);
    } finally {
      setIsExportingPng(false);
    }
  };

  // Save to Google Drive (with on-demand auth)
  const handleSaveToDrive = async () => {
    try {
      setIsSavingDrive(true);
      setDriveSavedLink(null);

      // Check if access token is available; if not, prompt on-demand
      let token = await getAccessToken();
      if (!token) {
        const signRes = await googleSignIn();
        token = signRes?.accessToken || null;
      }

      const element = document.getElementById(targetElementId);
      if (!element) {
        throw new Error('Arte não encontrada para exportar ao Drive.');
      }

      // Generate PNG data url
      const dataUrl = await toPng(element, {
        quality: 0.98,
        pixelRatio: 2.5,
      });

      const title =
        content.caixa_titulo?.texto || 'Campanha Coagro Agro';

      const fileName = `Coagro_Agro_${title.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.png`;

      const uploaded = await uploadToGoogleDrive({
        name: fileName,
        mimeType: 'image/png',
        data: dataUrl,
        description: `Arte oficial gerada para a divisão AGRO do Grupo Coagro.\nLegenda: ${content.legenda_post || ''}`,
      });

      if (uploaded.webViewLink) {
        setDriveSavedLink(uploaded.webViewLink);
      }
    } catch (err: any) {
      console.error('Erro ao salvar no Google Drive:', err);
      alert('Erro ao salvar no Google Drive: ' + err.message);
    } finally {
      setIsSavingDrive(false);
    }
  };

  // Copy pure JSON (strict format adhering to user specification)
  const handleCopyJson = () => {
    const cleanObject = formatCleanRenderJson(content);
    const jsonString = JSON.stringify(cleanObject, null, 2);
    navigator.clipboard.writeText(jsonString);
    setCopiedType('json');
    setTimeout(() => setCopiedType(null), 2500);
  };

  // Copy Instagram Caption
  const handleCopyCaption = () => {
    const caption = content.legenda_instagram || content.legenda_post;
    if (caption) {
      navigator.clipboard.writeText(caption);
      setCopiedType('caption');
      setTimeout(() => setCopiedType(null), 2500);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-4 space-y-4 font-['Inter']">
      {/* Styling Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 pb-3">
        {/* Format Selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-gray-500 uppercase font-['Exo_2'] flex items-center gap-1">
            <Layout className="w-3.5 h-3.5 text-[#004d40]" /> Proporção:
          </span>
          <div className="flex items-center bg-gray-100 p-0.5 rounded-lg text-xs">
            <button
              onClick={() => onSetFormat('feed-quadrado')}
              className={`px-2 py-1 rounded font-semibold transition ${
                format === 'feed-quadrado' ? 'bg-white text-[#004d40] shadow-xs' : 'text-gray-600'
              }`}
            >
              1:1
            </button>
            <button
              onClick={() => onSetFormat('feed-retrato')}
              className={`px-2 py-1 rounded font-semibold transition ${
                format === 'feed-retrato' ? 'bg-white text-[#004d40] shadow-xs' : 'text-gray-600'
              }`}
            >
              4:5
            </button>
            <button
              onClick={() => onSetFormat('story')}
              className={`px-2 py-1 rounded font-semibold transition ${
                format === 'story' ? 'bg-white text-[#004d40] shadow-xs' : 'text-gray-600'
              }`}
            >
              9:16
            </button>
          </div>
        </div>

        {/* Template Layout Selector (Blueprint) */}
        {onSetTemplateLayout && (
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-gray-500 uppercase font-['Exo_2'] flex items-center gap-1">
              <Columns2 className="w-3.5 h-3.5 text-[#004d40]" /> Template:
            </span>
            <div className="flex items-center bg-gray-100 p-0.5 rounded-lg text-xs">
              <button
                onClick={() => onSetTemplateLayout('split-vertical')}
                title="Split Vertical (Ref. Stella Artois - Frascos/Defensivos)"
                className={`px-2 py-1 rounded font-semibold transition flex items-center gap-1 ${
                  templateLayout === 'split-vertical'
                    ? 'bg-white text-[#004d40] shadow-xs font-bold'
                    : 'text-gray-600'
                }`}
              >
                <Columns2 className="w-3 h-3 text-[#004d40]" />
                <span>Split</span>
              </button>
              <button
                onClick={() => onSetTemplateLayout('hero-central')}
                title="Hero Central (Ref. Itaipava - Caixas/Sacos/Etiqueta Flutuante)"
                className={`px-2 py-1 rounded font-semibold transition flex items-center gap-1 ${
                  templateLayout === 'hero-central'
                    ? 'bg-white text-[#004d40] shadow-xs font-bold'
                    : 'text-gray-600'
                }`}
              >
                <Maximize2 className="w-3 h-3 text-[#ffab00]" />
                <span>Central</span>
              </button>
            </div>
          </div>
        )}

        {/* HeroCentral Bounding Box Selector */}
        {templateLayout === 'hero-central' && onSetImageBoxFormat && (
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-gray-500 uppercase font-['Exo_2'] flex items-center gap-1">
              <Box className="w-3.5 h-3.5 text-[#004d40]" /> Box Imagem:
            </span>
            <div className="flex items-center bg-gray-100 p-0.5 rounded-lg text-xs">
              <button
                type="button"
                onClick={() => onSetImageBoxFormat('rectangular')}
                title="Bounding Box Retangular (900x630)"
                className={`px-2 py-1 rounded font-semibold transition flex items-center gap-1 cursor-pointer ${
                  imageBoxFormat === 'rectangular'
                    ? 'bg-white text-[#004d40] shadow-xs font-bold'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <span>900x630</span>
              </button>
              <button
                type="button"
                onClick={() => onSetImageBoxFormat('square')}
                title="Bounding Box Quadrado (630x630)"
                className={`px-2 py-1 rounded font-semibold transition flex items-center gap-1 cursor-pointer ${
                  imageBoxFormat === 'square'
                    ? 'bg-white text-[#004d40] shadow-xs font-bold'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <span>630x630</span>
              </button>
            </div>
          </div>
        )}

        {/* Theme Selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-gray-500 uppercase font-['Exo_2'] flex items-center gap-1">
            <Palette className="w-3.5 h-3.5 text-[#ffab00]" /> Tema Fundo:
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => onSetTheme('campo-agro')}
              title="Foto Rural com Overlay (Automático)"
              className={`w-6 h-6 rounded-full bg-emerald-800 border-2 transition overflow-hidden flex items-center justify-center ${
                theme === 'campo-agro' ? 'border-[#ffab00] scale-110 shadow-sm ring-2 ring-[#ffab00]/30' : 'border-transparent'
              }`}
            >
              <span className="text-[9px]">🌾</span>
            </button>
            <button
              onClick={() => onSetTheme('verde-coagro')}
              title="Verde Institucional Coagro (#004d40)"
              className={`w-6 h-6 rounded-full bg-[#004d40] border-2 transition ${
                theme === 'verde-coagro' ? 'border-[#ffab00] scale-110 shadow-sm ring-2 ring-[#ffab00]/30' : 'border-transparent'
              }`}
            />
            <button
              onClick={() => onSetTheme('azul-coagro')}
              title="Azul Publicitário Coagro (#001C71)"
              className={`w-6 h-6 rounded-full bg-[#001C71] border-2 transition ${
                theme === 'azul-coagro' ? 'border-[#ffab00] scale-110 shadow-sm ring-2 ring-[#ffab00]/30' : 'border-transparent'
              }`}
            />
            <button
              onClick={() => onSetTheme('clean-branco')}
              title="Fundo Claro Neutro"
              className={`w-6 h-6 rounded-full bg-white border-2 border-gray-300 transition ${
                theme === 'clean-branco' ? 'border-[#004d40] scale-110 shadow-sm ring-2 ring-[#004d40]/30' : ''
              }`}
            />
          </div>
        </div>

        {/* Official Logo Variation Selector (Skill Variations 1-6) */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-gray-500 uppercase font-['Exo_2']">Logo Rodapé:</span>
          <select
            value={logoVariant}
            onChange={(e) => onSetLogoVariant(e.target.value as LogoVariant)}
            className="text-xs py-1 px-2 rounded-lg border border-gray-300 bg-white text-gray-800 focus:outline-none focus:ring-1 focus:ring-[#004d40]"
          >
            <option value="h-branca">Horizontal Branca (Padrão)</option>
            <option value="h-azul">Horizontal Azul</option>
            <option value="h-mono-branca">Horizontal Mono Branca</option>
            <option value="v-branca">Vertical Branca</option>
            <option value="v-azul">Vertical Azul</option>
            <option value="v-mono-branca">Vertical Mono Branca</option>
          </select>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          {/* Baixar Imagem PNG */}
          <button
            onClick={handleDownloadPng}
            disabled={isExportingPng}
            className="px-4 py-2 bg-[#004d40] hover:bg-[#00796b] text-white rounded-xl text-xs font-bold font-['Exo_2'] tracking-wide uppercase flex items-center gap-2 shadow-sm transition active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            {isExportingPng ? (
              <RefreshCw className="w-4 h-4 animate-spin text-[#ffab00]" />
            ) : (
              <Download className="w-4 h-4 text-[#ffab00]" />
            )}
            <span>Baixar Imagem PNG</span>
          </button>

          {/* Backup no Google Drive: Nativo e Silencioso em Background */}
          <div
            title="Backup e versionamento nativo automático ativado no Google Drive para histórico de criação"
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-50 text-emerald-800 rounded-xl text-xs font-semibold border border-emerald-200/80 cursor-default select-none"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <HardDrive className="w-3.5 h-3.5 text-emerald-700" />
            <span>Backup Drive (Nativo)</span>
          </div>

          {/* Drive link if just saved */}
          {driveSavedLink && (
            <a
              href={driveSavedLink}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-900 bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-200"
            >
              <span>Abrir no Drive</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>

        {/* Copy Tools */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyCaption}
            className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition active:scale-95"
            title="Copiar texto da legenda oficial com hashtags do agronegócio"
          >
            {copiedType === 'caption' ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700 font-bold">Legenda Copiada!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-gray-600" />
                <span>Copiar Legenda</span>
              </>
            )}
          </button>

          <button
            onClick={handleCopyJson}
            className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition active:scale-95"
            title="Copiar JSON estrito da peça"
          >
            {copiedType === 'json' ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700 font-bold">JSON Copiado!</span>
              </>
            ) : (
              <>
                <FileCode className="w-3.5 h-3.5 text-gray-600" />
                <span>Copiar JSON</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
