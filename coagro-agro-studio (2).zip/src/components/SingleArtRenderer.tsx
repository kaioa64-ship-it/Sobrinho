import React, { useEffect, useState } from 'react';
import { AgroPostContent, CanvasFormat, CanvasTheme, TemplateLayout } from '../types/agro';
import { LogoVariant } from '../assets/coagroLogos';
import { PULVERIZADOR_XP16_SVG } from '../assets/productPackshots';
import { removeWhiteBackground } from '../lib/imageTransparency';
import { formatBrlValue, formatBrlWithSymbol } from '../lib/priceFormatter';
import { resolveCommunicationMode } from '../lib/communicationMode';
import { cleanNoise, normalizeBenefits, resolveDefaultCta } from '../lib/contentNormalizer';
import { resolveBackgroundFromPrompt } from '../lib/backgroundResolver';
import { processAdaptiveProduct, AdaptiveProductInfo } from '../lib/alphaBounds';
import { BackgroundLayer } from './art-renderer/BackgroundLayer';
import { HeroCentral } from './art-renderer/templates/HeroCentral';
import { SplitVertical } from './art-renderer/templates/SplitVertical';
import { CanvasEmptyState } from './art-renderer/CanvasEmptyState';

interface SingleArtRendererProps {
  content: AgroPostContent;
  format: CanvasFormat;
  theme: CanvasTheme;
  templateLayout?: TemplateLayout;
  logoVariant?: LogoVariant;
  productImage?: string;
  backgroundImage?: string;
  badgeText?: string;
  containerId?: string;
  imageBoxFormat?: 'rectangular' | 'square';
}

export const SingleArtRenderer: React.FC<SingleArtRendererProps> = ({
  content,
  format,
  theme,
  templateLayout,
  logoVariant,
  productImage,
  backgroundImage,
  containerId = 'agro-single-art-canvas',
  imageBoxFormat,
}) => {
  const isStory =
    format === 'story' ||
    content.formato_gerado?.toLowerCase() === 'story' ||
    content.formato?.toLowerCase() === 'story';

  // No Story 9:16, Hero Central é o padrão recomendado (RF-03)
  const rawTemplate =
    templateLayout ||
    content.template_layout ||
    (isStory ? 'hero-central' : 'split-vertical');
  const isSplit = rawTemplate.toLowerCase().includes('split');

  // Normalização de textos com limpeza de ruídos - SEM valores pré-selecionados
  const rawTitle =
    content.textos_hero?.titulo ||
    content.textos_da_arte?.titulo_impacto ||
    content.caixa_titulo?.texto ||
    '';
  const title = cleanNoise(rawTitle);

  const rawHighlight =
    content.textos_hero?.palavra_destaque_ouro ||
    content.textos_da_arte?.palavra_destaque ||
    content.caixa_titulo?.palavra_ouro ||
    content.caixa_titulo?.palavra_ouro_destaque ||
    '';
  const highlight = cleanNoise(rawHighlight);

  const rawSubtitle =
    content.textos_hero?.subtitulo ||
    content.textos_da_arte?.subtitulo ||
    content.caixa_subtitulo?.texto ||
    '';
  const subtitle = cleanNoise(rawSubtitle);

  const rawBenefits =
    content.diferenciais_tecnicos ||
    content.textos_da_arte?.bullets_tecnicos ||
    content.beneficios_tecnicos ||
    [];
  const benefits = normalizeBenefits(rawBenefits);

  // Resolução determinística do Modo de Comunicação (RF-01, RF-02, RF-06)
  const price = content.modulo_preco || content.textos_da_arte?.modulo_preco;
  const mode = resolveCommunicationMode(content.tipo_postagem, price);
  const hasPrice = mode !== 'INFORMATIVE';
  const currentPrice = hasPrice ? formatBrlValue(price?.valor_por) : '';
  const oldPrice =
    mode === 'PROMOTION' && price?.valor_de
      ? formatBrlWithSymbol(price.valor_de)
      : '';
  const condition = cleanNoise(price?.condicoes_pagamento || '');
  const rawCta = content.textos_da_arte?.cta;
  const cta = cleanNoise(
    rawCta || (title ? resolveDefaultCta(mode, content.categoria_produto) : '')
  );

  // Resolução de Temas e Fundos Fotográficos (RF-08)
  const effectiveTheme = theme || content.tema || 'campo-agro';
  const isLight = effectiveTheme === 'clean-branco';
  const isBlue = effectiveTheme === 'azul-coagro';
  const logo = logoVariant || (isLight ? 'h-azul' : 'h-mono-branca');

  const activeBackground = resolveBackgroundFromPrompt(
    content.fundo_imagem,
    backgroundImage,
    content.fundo_imagem_url
  );

  const isPhoto =
    ['campo-agro', 'fundo-gerado'].includes(effectiveTheme) &&
    Boolean(activeBackground);

  const backgroundStyle: React.CSSProperties = isBlue
    ? { background: 'radial-gradient(circle at 50% 40%, #002b82 0%, #001C71 80%)' }
    : isLight
    ? { background: 'radial-gradient(circle at 50% 40%, #ffffff 0%, #f1f5f9 85%)' }
    : { background: 'radial-gradient(circle at 50% 40%, #006b59 0%, #004d40 80%)' };

  // Processamento do produto: sem produto padrão, começa vazio se não fornecido
  const sourceProduct = productImage || '';
  const [processedProduct, setProcessedProduct] = useState(sourceProduct);
  const [adaptiveInfo, setAdaptiveInfo] = useState<AdaptiveProductInfo>({
    croppedSrc: sourceProduct,
    bounds: null,
    orientation: 'compact',
    isWide: false,
    isSmall: false,
  });

  useEffect(() => {
    let mounted = true;

    // Redefine o estado adaptativo para nunca reaproveitar a imagem anterior
    setAdaptiveInfo({
      croppedSrc: sourceProduct,
      bounds: null,
      orientation: 'compact',
      isWide: false,
      isSmall: false,
    });

    if (!sourceProduct) {
      setProcessedProduct('');
      return;
    }

    if (sourceProduct.startsWith('data:image/svg+xml')) {
      setProcessedProduct(sourceProduct);
      return () => {
        mounted = false;
      };
    }

    removeWhiteBackground(sourceProduct)
      .then(async (transparentImg) => {
        if (!mounted) return;
        setProcessedProduct(transparentImg);

        // Calcula bounding box alfa e faz tight crop para ancoragem física pela base
        const adaptive = await processAdaptiveProduct(transparentImg);
        if (mounted) {
          setAdaptiveInfo(adaptive);
        }
      })
      .catch(() => {
        if (mounted) {
          setProcessedProduct(sourceProduct);
          setAdaptiveInfo({
            croppedSrc: sourceProduct,
            bounds: null,
            orientation: 'compact',
            isWide: false,
            isSmall: false,
          });
        }
      });

    return () => {
      mounted = false;
    };
  }, [sourceProduct]);

  const aspectClass = isStory
    ? 'aspect-[9/16] max-w-[390px]'
    : format === 'feed-retrato'
    ? 'aspect-[4/5] max-w-[440px]'
    : 'aspect-square max-w-[480px]';

  const canvasClasses = `w-full ${aspectClass} relative rounded-3xl shadow-2xl overflow-hidden border border-emerald-800/30 font-['Inter']`;
  const titleColor = isLight ? 'text-[#001C71]' : 'text-white';
  const subtitleColor = isLight ? 'text-gray-600' : 'text-[#E5E7EB]';

  // A imagem final do produto usa o recorte justo dos pixels visíveis (tight crop) para ancoragem pela base
  const finalProductImg = adaptiveInfo.croppedSrc || processedProduct;

  // Estado totalmente zerado: sem imagem e sem título e sem benefícios
  const isArtEmpty = !sourceProduct && !title && benefits.length === 0;

  return (
    <div className="flex justify-center items-center w-full select-none">
      <div id={containerId} style={backgroundStyle} className={canvasClasses}>
        <BackgroundLayer
          theme={effectiveTheme}
          activeBackground={activeBackground}
          isPhoto={isPhoto}
          isBlue={isBlue}
        />

        {isArtEmpty ? (
          <CanvasEmptyState logoVariant={logo} isStory={isStory} />
        ) : isSplit ? (
          <SplitVertical
            title={title}
            highlight={highlight}
            titleColor={titleColor}
            subtitle={subtitle}
            subtitleColor={subtitleColor}
            processedProduct={finalProductImg}
            isStory={isStory}
            logoVariant={logo}
            mode={mode}
            hasPrice={hasPrice}
            currentPrice={currentPrice}
            oldPrice={oldPrice}
            condition={condition}
            benefits={benefits}
            cta={cta}
            isWide={adaptiveInfo.isWide}
          />
        ) : (
          <HeroCentral
            title={title}
            highlight={highlight}
            titleColor={titleColor}
            subtitle={subtitle}
            subtitleColor={subtitleColor}
            processedProduct={finalProductImg}
            isStory={isStory}
            logoVariant={logo}
            mode={mode}
            hasPrice={hasPrice}
            currentPrice={currentPrice}
            oldPrice={oldPrice}
            condition={condition}
            benefits={benefits}
            cta={cta}
            orientation={adaptiveInfo.orientation}
            isWide={adaptiveInfo.isWide}
            isSmall={adaptiveInfo.isSmall}
            imageBoxFormat={imageBoxFormat || (content as any).image_box_format}
          />
        )}
      </div>
    </div>
  );
};
