/**
 * Client-side Automatic Background Transparency Processor
 * Detects white/light backgrounds from e-commerce packshots (e.g. Pulverizador XP 16, defensivos, frascos)
 * and turns them into clean transparent PNG data URLs with edge softening.
 */

export interface TransparencyOptions {
  threshold?: number;       // RGB threshold to consider white (e.g. 235-255)
  colorDistance?: number;   // Max color distance from corner background color
  featherRadius?: number;   // Smooth edge blending
}

/**
 * Automatically removes solid white/light background from an image URL or base64.
 * Returns a Promise that resolves with a transparent PNG data-URL.
 */
export async function removeWhiteBackground(
  imageUrl: string,
  options: TransparencyOptions = {}
): Promise<string> {
  const {
    threshold = 230,
    colorDistance = 35,
  } = options;

  return new Promise((resolve) => {
    // If empty or already an SVG data URL, return as-is
    if (!imageUrl || imageUrl.startsWith('data:image/svg+xml')) {
      resolve(imageUrl);
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d', { willReadFrequently: true });

        if (!ctx) {
          resolve(imageUrl);
          return;
        }

        // Limit dimensions for fast processing
        const maxDim = 1200;
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;

        if (width > maxDim || height > maxDim) {
          const ratio = Math.min(maxDim / width, maxDim / height);
          width = Math.round(width * ratio);
          height = Math.round(height * ratio);
        }

        canvas.width = width;
        canvas.height = height;

        ctx.drawImage(img, 0, 0, width, height);

        const imgData = ctx.getImageData(0, 0, width, height);
        const data = imgData.data;

        // Sample corners to detect background color
        const samplePoints = [
          [2, 2],
          [width - 3, 2],
          [2, height - 3],
          [width - 3, height - 3],
          [Math.floor(width / 2), 2],
        ];

        let bgR = 0, bgG = 0, bgB = 0;
        let validSamples = 0;

        for (const [sx, sy] of samplePoints) {
          const idx = (sy * width + sx) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          const a = data[idx + 3];

          // If corner is already transparent, image might already be PNG cutout
          if (a < 50) {
            resolve(imageUrl);
            return;
          }

          // Check if corner is near-white or light gray
          if (r > 210 && g > 210 && b > 210) {
            bgR += r;
            bgG += g;
            bgB += b;
            validSamples++;
          }
        }

        // If corners are not light/white, don't destructively alter the photo
        if (validSamples < 2) {
          resolve(imageUrl);
          return;
        }

        bgR = Math.round(bgR / validSamples);
        bgG = Math.round(bgG / validSamples);
        bgB = Math.round(bgB / validSamples);

        // Process pixels
        const totalPixels = width * height;
        for (let i = 0; i < totalPixels; i++) {
          const offset = i * 4;
          const r = data[offset];
          const g = data[offset + 1];
          const b = data[offset + 2];

          // Distance from corner background color
          const dist = Math.sqrt(
            Math.pow(r - bgR, 2) +
            Math.pow(g - bgG, 2) +
            Math.pow(b - bgB, 2)
          );

          // Check if pixel is white or close to sampled background
          const isWhiteThreshold = r >= threshold && g >= threshold && b >= threshold;
          const isNearBg = dist < colorDistance;

          if (isWhiteThreshold || isNearBg) {
            // Soft alpha feathering based on distance
            if (dist < colorDistance * 0.6) {
              data[offset + 3] = 0; // 100% transparent
            } else {
              const alphaRatio = (dist - colorDistance * 0.6) / (colorDistance * 0.4);
              data[offset + 3] = Math.min(data[offset + 3], Math.round(alphaRatio * 255));
            }
          }
        }

        ctx.putImageData(imgData, 0, 0);
        const transparentDataUrl = canvas.toDataURL('image/png');
        resolve(transparentDataUrl);
      } catch (err) {
        // Fallback silently if canvas is tainted by CORS
        console.warn('Canvas transparency fallback:', err);
        resolve(imageUrl);
      }
    };

    img.onerror = () => {
      resolve(imageUrl);
    };

    img.src = imageUrl;
  });
}
