export const cleanNoise = (value?: string): string =>
  (value || '')
    .replace(/divis[ãa]o\s+agropecu[áa]ria/gi, '')
    .replace(/\s+/g, ' ')
    .trim();

export const normalizeBenefit = (value?: string): string =>
  cleanNoise(value)
    .replace(/[.,;:]+$/, '')
    .trim();

export const normalizeBenefits = (values?: string[]): string[] =>
  (values || [])
    .map(normalizeBenefit)
    .filter(Boolean)
    .slice(0, 3);

export function resolveDefaultCta(
  mode: 'PROMOTION' | 'SINGLE_PRICE' | 'INFORMATIVE',
  category?: string
): string {
  if (mode === 'PROMOTION') return 'GARANTA JÁ O SEU';
  if (mode === 'SINGLE_PRICE') return 'CONSULTE DISPONIBILIDADE';

  const normalized = (category || '').toLowerCase();
  if (normalized.includes('vacina') || normalized.includes('veterin')) {
    return 'FALE COM NOSSA EQUIPE';
  }

  return 'SAIBA MAIS';
}
