import React, { useState } from 'react';
import { AgroPostContent, CanvasFormat, CanvasTheme, PresetProduct, TemplateLayout, EMPTY_AGRO_CONTENT } from './types/agro';
import { LogoVariant } from './assets/coagroLogos';
import { AGRO_PRESETS } from './data/agroPresets';
import { Header } from './components/Header';
import { SingleArtRenderer } from './components/SingleArtRenderer';
import { InputPanel } from './components/InputPanel';
import { ExportToolbar } from './components/ExportToolbar';
import { JsonViewerModal } from './components/JsonViewerModal';
import { getAccessToken } from './lib/firebase';
import { uploadToGoogleDrive } from './lib/googleDrive';
import { resolveDefaultTemplate } from './lib/layoutRules';
import { CommunicationMode } from './lib/communicationMode';
import { toPng } from 'html-to-image';
import { Eye, Sparkles } from 'lucide-react';

export default function App() {
  // Estado inicial 100% zerado - sem nenhum produto ou texto pré-carregado
  const [currentContent, setCurrentContent] = useState<AgroPostContent>(
    EMPTY_AGRO_CONTENT
  );
  const [productImage, setProductImage] = useState<string>('');
  const [backgroundImage, setBackgroundImage] = useState<string | undefined>(undefined);

  // Canvas styling states (Padrão Story 9:16 e Hero Central per especificação)
  const [canvasFormat, setCanvasFormat] = useState<CanvasFormat>('story');
  const [canvasTheme, setCanvasTheme] = useState<CanvasTheme>('campo-agro');
  const [templateLayout, setTemplateLayout] = useState<TemplateLayout>('hero-central');
  const [templateWasManuallySelected, setTemplateWasManuallySelected] = useState(false);
  const [logoVariant, setLogoVariant] = useState<LogoVariant>('h-branca');
  const [imageBoxFormat, setImageBoxFormat] = useState<'rectangular' | 'square'>('rectangular');

  const handleSelectTemplate = (template: TemplateLayout) => {
    setTemplateLayout(template);
    setTemplateWasManuallySelected(true);
  };

  const handleSelectFormat = (fmt: CanvasFormat) => {
    setCanvasFormat(fmt);
    if (fmt === 'story' && !templateWasManuallySelected) {
      setTemplateLayout(resolveDefaultTemplate('story'));
    }
  };

  // Generation status
  const [isGenerating, setIsGenerating] = useState(false);

  // Modals
  const [isJsonModalOpen, setIsJsonModalOpen] = useState(false);

  // Preset Selection
  const handleSelectPreset = (preset: PresetProduct) => {
    setProductImage(preset.imageUrl);
    setCurrentContent(preset.defaultContent);
    if (preset.defaultContent.template_layout) {
      setTemplateLayout(preset.defaultContent.template_layout);
      setTemplateWasManuallySelected(true);
    }
    if (preset.backgroundSampleUrl || preset.defaultContent.fundo_imagem_url) {
      setBackgroundImage(preset.backgroundSampleUrl || preset.defaultContent.fundo_imagem_url);
    } else if (preset.defaultContent.fundo_imagem && (preset.defaultContent.fundo_imagem.startsWith('http') || preset.defaultContent.fundo_imagem.startsWith('data:'))) {
      setBackgroundImage(preset.defaultContent.fundo_imagem);
    } else {
      setBackgroundImage(undefined);
    }

    if (preset.defaultContent.formato_gerado === 'Story' || preset.defaultContent.formato === 'story') {
      setCanvasFormat('story');
    } else {
      setCanvasFormat('feed-quadrado');
    }
    if (preset.defaultContent.tema) {
      setCanvasTheme(preset.defaultContent.tema);
    } else {
      setCanvasTheme('campo-agro');
    }
  };

  // Auto-save to Google Drive in background for internal comparison
  const triggerDriveAutoSave = async (contentToSave: AgroPostContent) => {
    try {
      const token = await getAccessToken();
      if (!token) return;

      setTimeout(async () => {
        try {
          const el = document.getElementById('agro-single-art-canvas');
          if (!el) return;
          const dataUrl = await toPng(el, { quality: 0.95, pixelRatio: 2 });
          const title =
            contentToSave.textos_da_arte?.titulo_impacto ||
            contentToSave.caixa_titulo?.texto ||
            'Campanha_Agro';
          await uploadToGoogleDrive({
            name: `Coagro_Agro_${title.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.png`,
            mimeType: 'image/png',
            data: dataUrl,
            description: `Auto-salvo internamente para fins de comparação.\nLegenda: ${contentToSave.legenda_instagram || contentToSave.legenda_post || ''}`,
          });
          console.log('Design salvo automaticamente no Google Drive.');
        } catch (e) {
          console.warn('Auto-save interno no Drive:', e);
        }
      }, 1000);
    } catch {
      // Silent
    }
  };

  // Content Generation API Call - Tratado estritamente como nova instância isolada
  const handleGenerateContent = async (params: {
    imageBase64?: string;
    mimeType?: string;
    prompt?: string;
    format: 'feed' | 'story';
    templateLayout?: TemplateLayout;
    isManualTemplate?: boolean;
    communicationMode?: CommunicationMode;
    communicationSelection?: 'AUTO' | 'PROMOTION' | 'SINGLE_PRICE' | 'INFORMATIVE';
    targetFocus?: string;
    priceInfo?: {
      ativo: boolean;
      valor_de: string;
      valor_por: string;
      condicoes_pagamento?: string;
    };
    isNewImage?: boolean;
  }) => {
    try {
      setIsGenerating(true);

      // Limpeza ativa de contexto anterior para garantir nova instância limpa
      if (params.isNewImage) {
        setBackgroundImage(undefined);
      }

      // Constrói payload limpo sem resquícios de estados ou imagens anteriores
      const payload = {
        imageBase64: params.imageBase64,
        mimeType: params.mimeType || 'image/jpeg',
        prompt: params.prompt?.trim() || undefined,
        format: params.format,
        templateLayout: params.templateLayout,
        isManualTemplate: Boolean(params.isManualTemplate ?? templateWasManuallySelected),
        communicationMode: params.communicationMode,
        communicationSelection: params.communicationSelection,
        targetFocus: params.targetFocus,
        priceInfo: params.priceInfo?.ativo
          ? {
              ativo: true,
              valor_de: params.priceInfo.valor_de || '',
              valor_por: params.priceInfo.valor_por || '',
              condicoes_pagamento: params.priceInfo.condicoes_pagamento || '',
            }
          : undefined,
        isNewImage: Boolean(params.isNewImage),
      };

      const res = await fetch('/api/generate-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Erro ao processar dados.');
      }

      const generatedData: AgroPostContent = json.data;
      setCurrentContent(generatedData);

      const generatedIsStory =
        generatedData.formato_gerado?.toLowerCase() === 'story' ||
        generatedData.formato?.toLowerCase() === 'story';

      // A recomendação inteligente da IA define o melhor layout para o item (ex: split para máquinas)
      if (generatedData.template_layout) {
        setTemplateLayout(generatedData.template_layout);
        setTemplateWasManuallySelected(false);
      } else if (!templateWasManuallySelected) {
        if (generatedIsStory) {
          setTemplateLayout(resolveDefaultTemplate('story'));
        }
      }

      // Adjust format automatically
      if (
        generatedData.formato_gerado?.toLowerCase() === 'story' ||
        generatedData.formato?.toLowerCase() === 'story'
      ) {
        setCanvasFormat('story');
      } else {
        setCanvasFormat('feed-quadrado');
      }

      // Automatically apply inferred theme and photographic background from backend
      if (generatedData.tema) {
        setCanvasTheme(generatedData.tema);
      }

      if (generatedData.fundo_imagem_url) {
        setBackgroundImage(generatedData.fundo_imagem_url);
      } else if (
        generatedData.fundo_imagem &&
        (generatedData.fundo_imagem.startsWith('http') || generatedData.fundo_imagem.startsWith('data:'))
      ) {
        setBackgroundImage(generatedData.fundo_imagem);
      } else {
        setBackgroundImage(undefined);
      }

      // Trigger background auto-save to Google Drive
      triggerDriveAutoSave(generatedData);
    } catch (err: any) {
      console.error('Erro na geração:', err);
      alert('Erro ao gerar conteúdo AGRO: ' + err.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const currentTitle =
    currentContent.textos_hero?.titulo ||
    currentContent.textos_da_arte?.titulo_impacto ||
    '';
  const titleCharCount = currentTitle.trim().length;
  const isTitleIdeal = titleCharCount > 0 && titleCharCount <= 28;
  const isTitleWarning = titleCharCount > 28 && titleCharCount <= 35;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#1F2937] flex flex-col font-['Inter']">
      {/* 1. Header with ONLY Coagro Logo and subtle JSON viewer button */}
      <Header onOpenJsonModal={() => setIsJsonModalOpen(true)} />

      {/* 2. Main Workspace */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex-1">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Input and Processing Engine Controls (5 cols) */}
          <div className="lg:col-span-5 space-y-5">
            <InputPanel
              onGenerateContent={handleGenerateContent}
              onSelectPreset={handleSelectPreset}
              isGenerating={isGenerating}
              currentImage={productImage}
              onSetProductImage={(url) => setProductImage(url)}
              currentContent={currentContent}
              onUpdateContent={(updated) => setCurrentContent(updated)}
              selectedFormat={canvasFormat}
              onSelectFormat={handleSelectFormat}
              selectedTemplate={templateLayout}
              onSelectTemplate={handleSelectTemplate}
              imageBoxFormat={imageBoxFormat}
              onSelectImageBoxFormat={setImageBoxFormat}
            />

            {/* Quick Caption & Legend Preview (Official Instagram text) */}
            {(currentContent.legenda_instagram || currentContent.legenda_post) && (
              <div className="bg-white rounded-2xl p-5 border border-gray-200 shadow-2xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-gray-700 font-['Exo_2']">
                    Legenda Oficial Gerada
                  </span>
                  <span className="text-[10px] text-gray-400 font-mono">Com hashtags técnicas</span>
                </div>
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-xs text-gray-700 leading-relaxed max-h-40 overflow-y-auto whitespace-pre-wrap font-sans">
                  {currentContent.legenda_instagram || currentContent.legenda_post}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Automated Live HTML/CSS Renderer & Export Toolbar (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            {/* Export & Customization Toolbar */}
            <ExportToolbar
              content={currentContent}
              format={canvasFormat}
              onSetFormat={handleSelectFormat}
              theme={canvasTheme}
              onSetTheme={setCanvasTheme}
              templateLayout={templateLayout}
              onSetTemplateLayout={handleSelectTemplate}
              imageBoxFormat={imageBoxFormat}
              onSetImageBoxFormat={setImageBoxFormat}
              logoVariant={logoVariant}
              onSetLogoVariant={setLogoVariant}
              user={null}
              onPromptLogin={() => {}}
              targetElementId="agro-single-art-canvas"
            />

            {/* Live Canvas Box */}
            <div className="bg-white/80 backdrop-blur-xs rounded-2xl p-6 border border-gray-200 shadow-sm flex flex-col items-center justify-center min-h-[520px]">
              <div className="w-full flex items-center justify-between mb-3 border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-[#004d40]" />
                  <span className="font-['Exo_2'] font-bold text-sm text-gray-800">
                    Arte Final em Camadas (Renderizador Oficial)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {titleCharCount > 0 && (
                    <span
                      title="Limite ideal para redes sociais: até 28 caracteres garantem leitura rápida e impacto máximo em Stories e Feed"
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 transition-all ${
                        isTitleIdeal
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                          : isTitleWarning
                          ? 'bg-amber-50 text-amber-900 border-amber-300'
                          : 'bg-rose-50 text-rose-800 border-rose-300 animate-pulse'
                      }`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      <span>Título: {titleCharCount}/28 chars</span>
                      <span className="opacity-60">•</span>
                      <span>{isTitleIdeal ? 'Limite Ideal' : isTitleWarning ? 'Limite Recomendado' : 'Título Longo'}</span>
                    </span>
                  )}
                  <span className="text-[11px] font-mono text-gray-500 hidden sm:inline">
                    Vetor Oficial Coagro • Cores da Marca
                  </span>
                </div>
              </div>

              {/* Automatic Photographic Background Prompt Notification Tag */}
              {currentContent.fundo_imagem && (
                <div className="w-full mb-4 px-3.5 py-2.5 rounded-xl bg-emerald-50/80 border border-emerald-200/80 flex items-start gap-2.5 text-left">
                  <div className="p-1 rounded-md bg-[#004d40] text-[#ffab00] shrink-0 mt-0.5 shadow-2xs">
                    <Sparkles className="w-3.5 h-3.5 fill-current" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#004d40] font-['Exo_2']">
                        Fundo Fotográfico Otimizado (IA Aplicado):
                      </span>
                    </div>
                    <p className="text-[11px] text-gray-700 leading-snug italic line-clamp-2 mt-0.5">
                      &ldquo;{currentContent.fundo_imagem}&rdquo;
                    </p>
                  </div>
                </div>
              )}

              {/* Render Single Art (Feed ou Story) */}
              <SingleArtRenderer
                content={currentContent}
                format={canvasFormat}
                theme={canvasTheme}
                templateLayout={templateLayout}
                logoVariant={logoVariant}
                productImage={productImage}
                backgroundImage={backgroundImage}
                containerId="agro-single-art-canvas"
                imageBoxFormat={imageBoxFormat}
              />
            </div>
          </div>
        </div>
      </main>

      {/* 3. Modals */}
      <JsonViewerModal
        isOpen={isJsonModalOpen}
        onClose={() => setIsJsonModalOpen(false)}
        content={currentContent}
        onUpdateContent={(updated) => setCurrentContent(updated)}
      />
    </div>
  );
}
