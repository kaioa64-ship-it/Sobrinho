export type CommunicationType =
  | 'promocao'
  | 'preco-unico'
  | 'informativo'
  | 'promotion'
  | 'single-price'
  | 'informative'
  | 'informativo_novidade';

export type CommunicationSelection =
  | 'auto'
  | 'promocao'
  | 'preco-unico'
  | 'informativo';

export interface PriceModule {
  ativo?: boolean;
  valor_de?: string;
  valor_por?: string;
  condicoes_pagamento?: string;
  unidade?: string;
  condicao?: string;
}

export type ModuloPreco = PriceModule;

export interface CaixaTitulo {
  texto: string;
  palavra_ouro: string;
  palavra_ouro_destaque?: string;
  caracteres_usados?: number;
  limite?: number;
}

export interface CaixaSubtitulo {
  texto: string;
  caracteres_usados?: number;
  limite?: number;
}

export type CanvasFormat = 'feed-quadrado' | 'feed-retrato' | 'story';

export type TemplateLayout = 'split-vertical' | 'hero-central';

export type CanvasTheme =
  | 'verde-coagro'   // #004d40 Dominante Institucional
  | 'azul-coagro'    // #001C71 Azul Publicitário Oficial
  | 'clean-branco'   // #FFFFFF Fundo Claro
  | 'campo-agro'     // Fundo com foto do campo
  | 'fundo-gerado';

export interface TextosDaArte {
  titulo_impacto: string;
  palavra_destaque: string;
  subtitulo: string;
  bullets_tecnicos: string[];
  cta: string;
  modulo_preco?: ModuloPreco;
}

export interface TextosHero {
  titulo: string;
  palavra_destaque_ouro: string;
  subtitulo: string;
}

export interface AgroPostContent {
  linha?: string;
  tipo_postagem?: CommunicationType | string;
  categoria_produto?: string;
  formato_gerado?: 'Feed' | 'Story' | string;
  formato: 'feed' | 'story' | string;
  template_layout?: TemplateLayout;
  image_box_format?: 'rectangular' | 'square';
  tema?: CanvasTheme;
  prompt_fundo_ia?: string;
  fundo_imagem?: string;
  fundo_imagem_url?: string;
  textos_hero?: TextosHero;
  diferenciais_tecnicos?: string[];
  textos_da_arte?: TextosDaArte;
  caixa_titulo?: CaixaTitulo;
  caixa_subtitulo?: CaixaSubtitulo;
  beneficios_tecnicos?: string[];
  modulo_preco?: ModuloPreco;
  legenda_instagram?: string;
  legenda_post?: string;
}

export type AgroContent = AgroPostContent;

export interface PresetProduct {
  id: string;
  name: string;
  category: 'Defensivos' | 'Vacinas & Sanidade' | 'Fertilizantes' | 'Pecuária' | 'Sementes' | 'Equipamentos';
  description: string;
  imageUrl: string;
  badge: string;
  defaultContent: AgroPostContent;
  backgroundSampleUrl?: string;
}

export const EMPTY_AGRO_CONTENT: AgroPostContent = {
  linha: '',
  tipo_postagem: undefined,
  categoria_produto: '',
  formato: 'story',
  formato_gerado: 'Story',
  template_layout: 'hero-central',
  tema: 'campo-agro',
  textos_hero: {
    titulo: '',
    palavra_destaque_ouro: '',
    subtitulo: '',
  },
  textos_da_arte: {
    titulo_impacto: '',
    palavra_destaque: '',
    subtitulo: '',
    bullets_tecnicos: [],
    cta: '',
    modulo_preco: {
      ativo: false,
      valor_de: '',
      valor_por: '',
      condicoes_pagamento: '',
    },
  },
  caixa_titulo: {
    texto: '',
    palavra_ouro: '',
  },
  caixa_subtitulo: {
    texto: '',
  },
  diferenciais_tecnicos: [],
  beneficios_tecnicos: [],
  modulo_preco: {
    ativo: false,
    valor_de: '',
    valor_por: '',
    condicoes_pagamento: '',
  },
  legenda_instagram: '',
  legenda_post: '',
  fundo_imagem: '',
  fundo_imagem_url: '',
};
