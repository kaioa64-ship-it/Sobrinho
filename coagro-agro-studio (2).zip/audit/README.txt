# PASTA DE AUDITORIA E VALIDAÇÃO (FASES 1, 2, 3 E 4)
## Coagro Agro Studio — Refatoração Oficial

Esta pasta (`/audit/`) centraliza todos os códigos desenvolvidos e atualizados durante as **Fases 1, 2, 3 e 4** da refatoração oficial do **Coagro Agro Studio**.

Os arquivos aqui presentes são réplicas completas, prontas para auditoria, inspeção e download independente, sem interferir no funcionamento da aplicação principal.

---

### 📂 Mapa Completo de Arquivos na Pasta `/audit/`

| Arquivo (.txt) | Fase | Descrição / Responsabilidade |
| :--- | :--- | :--- |
| `communicationMode.ts.txt` | **Fase 1** | Resolução determinística dos três modos (`PROMOTION`, `SINGLE_PRICE` e `INFORMATIVE`). Prioridade da escolha manual do usuário. |
| `contentNormalizer.ts.txt` | **Fase 1 & 3** | Limpeza de ruídos de IA (ex: "Divisão Agropecuária"), normalização de pontuação dos benefícios e CTA contextual por modo e categoria. |
| `backgroundResolver.ts.txt` | **Fase 1, 2 & 3** | Catálogo de URLs rurais em alta resolução por contexto (máquinas, lavoura, pulverização, pecuária, solo). Retorna `undefined` para temas monocromáticos sem forçar foto fallback. |
| `layoutRules.ts.txt` | **Fase 2** | Constantes de proporção do Story 9:16 (`safeArea`, `rows: 9% 15% 43% 17% 8%`, clamps tipográficos) e função `resolveDefaultTemplate`. |
| `alphaBounds.ts.txt` | **Fase 2 & 4** | Algoritmo de varredura Alpha, cálculo de bounding box exata dos pixels visíveis, corte justo (*tight crop*) e classificação de orientação (`horizontal`, `vertical`, `compact`, `small`). |
| `PriceCard.tsx.txt` | **Fase 1 & 3** | Componente visual do preço: renderiza `DE: / POR:` em `PROMOTION`, apenas `R$ valor` em `SINGLE_PRICE`, e é omitido em `INFORMATIVE`. |
| `BackgroundLayer.tsx.txt` | **Fase 3** | Camada de fundo fotográfico/gradiente desacoplada com iluminação atmosférica e respeito estrito aos temas Verde, Azul e Clean. |
| `ArtHeader.tsx.txt` | **Fase 2 & 3** | Cabeçalho modular com o logotipo oficial Coagro com alinhamento proporcional (central ou à esquerda no Split). |
| `BenefitsList.tsx.txt` | **Fase 2 & 3** | Renderização dos diferenciais técnicos sem truncamento invisível (`badges-horizontal` para Hero Central e `list-vertical` para Split). |
| `ArtCta.tsx.txt` | **Fase 2 & 3** | Botão de chamada para ação estático e determinístico, livre de efeitos de hover ou transições que causem artefatos no PNG. |
| `HeroCentral.tsx.txt` | **Fase 2 & 4** | Template Hero Central com grade 9:16 proporcional, escala inteligente para produtos horizontais/pequenos e etiqueta de preço ancorada. |
| `SplitVertical.tsx.txt` | **Fase 2 & 4** | Template Split Vertical adaptado para Story 9:16 com duas colunas na área central e CTA em largura total no rodapé inferior. |
| `SingleArtRenderer.tsx.txt` | **Fase 1 a 4** | Orquestrador limpo de dados, vinculando o recorte Alpha, o cálculo do bounding box e a delegação de layout. |
| `types-agro.ts.txt` | **Fase 1 & 2** | Tipagem completa TypeScript (`CommunicationType`, `PriceModule`, `AgroPostContent`). |
| `InputPanel.tsx.txt` | **Fase 1** | Painel interativo com seletor dos 3 modos comerciais no editor em tempo real e alerta visual de caracteres. |
| `App.tsx.txt` | **Fase 2** | Inicialização determinística do formato Story em `hero-central` via `resolveDefaultTemplate('story')`. |
| `README.txt` | **Geral** | Este guia de referência e critérios de aceite. |

---

### 🧪 Critérios de Aceite Verificados (Fases 1, 2, 3 e 4)

* [x] **Três Modos Comerciais (RF-01, RF-02):** Dois preços exibem DE e valor final; um preço exibe apenas o valor vigente; nenhum preço oculta o bloco financeiro.
* [x] **Story 9:16 Estabilizado (RF-03, RF-04):** Hero Central como padrão na proporção `9% 15% 43% 17% 8%`; Split adaptado com rodapé completo.
* [x] **Segurança Visual (RF-05, RF-09):** Zero `truncate`, zero `line-clamp`; sem classes de `hover` ou `transition` no nó exportável.
* [x] **Temas Independentes (RF-08):** Verde, Azul e Clean renderizam sem carregar fotos de fundo indevidas.
* [x] **Produto Adaptativo (RF-08 Regras de Negócio & Fase 4):**
  * Detecção da caixa alfa visível do produto eliminando espaços vazios transparentes.
  * Ancoragem física exata pela base (`object-bottom`).
  * Classificação automática: produtos horizontais/largos (forrageira, arame) expandem a largura para evitar corte lateral; produtos pequenos (frascos de vacina) recebem ganho de presença visual.
* [x] **Modularização Arquitetural:** Separação em componentes dedicados (`BackgroundLayer`, `ArtHeader`, `BenefitsList`, `ArtCta`, `HeroCentral`, `SplitVertical`).
* [x] **TypeScript:** Código 100% tipado e validado (`tsc --noEmit` aprovado com 0 erros).
